package sjs.api.dictionary;
/****
 * <p> 
 * Title: DicType Class.
 * </p>
 * <p>
 * Description: A generic component of the Dictionary API which can store input of various wrapper-class objects as 
 * well as of programmer-defined objects like CalculatorValue object.   
 * </p>
 * @author JSGREWAL, Sumit, Shivam
 * @version 1.00 The Initial Version
 * @param <T> Generic (Any) Type.
 */
public class DicType<T> {
	// The one and only main-attribute of this object which will change its data-type according to the
	// input.
	T definition;

	/***
	 * The main-constructor of the DicType object which will take input of any type and
	 * convert it into a type safe (DicType) object. 
	 * @param input The input of any type which will be converted.
	 */
	public DicType (T input){
		definition = input;
	}

	/***
	 * Getters and Setters
	 */

	/***
	 * The getter method for obtaining the object in the CalculatorValue form for
	 * programmable calculator integration mode.
	 * @return The CalculatorValue form of the Object iff it is an actual CalculatorValue Object. Otherwise,
	 * a fake CalculatorValue is returned.
	 */
	public CalculatorValue getCalcValue() {
		String type = this.definition.getClass().getName();// Get the name of the data-type.
		if (type.equals("dictionary.CalculatorValue")) { // If the object is of CalculatorValue type
			return (CalculatorValue)definition; // then return it as a calculator value
		}
		else return new CalculatorValue(0,0,"VALUE NOT FOUND");
	}

	@Override
	/***
	 * The Modified toString Method returns the String form of the object in case of KM Tool-integration mode
	 * and String form of the CalculatorValue object in case of Programmable Calculator Integration Mode.
	 * Note: The returned String will be of the format which can be successfully fetched and saved in the repository.
	 * A blank string (String.length()==0) will be returned if the object is made of any non-supportable (except String & Calculator Value) type.
	 */
	public String toString() {
		// Fetch the name of object's type.
		String type = this.definition.getClass().getName(); 
		if (type.equals("java.lang.String")) { // If the object is of String wrapper class
			return this.definition.toString(); // return it's value in string form.
		} else if (type.equals("dictionary.CalculatorValue")) { // If the object is of CalculatorValue type
			return CalculatorValue.getString((CalculatorValue)this.definition); // return it's String form.
		}
		return ""; // Else return empty string.
	}

	/*	
	 *//*****************************
	 * Testing the Generic Object for its Attributes
	 * @param args
	 * Uncomment this method to check if the DicType Generic Object accepts input of String (KM Tool) or CalculatorValue
	 * (Programmable Calculator) type or not.
	 */

	/*
	public static void main(String[] args) {
		DicType<String> stringTest = new DicType<String>("ABC");
		// Check if the toString method works fine or not.
		String result = stringTest.toString();
		System.out.println(result);
		CalculatorValue v = new CalculatorValue(2,5,"h");
		DicType <CalculatorValue> calcVTest = new DicType<CalculatorValue>(v);
		String result2 = calcVTest.toString();
		System.out.println(result2);

	}
	 */
}
