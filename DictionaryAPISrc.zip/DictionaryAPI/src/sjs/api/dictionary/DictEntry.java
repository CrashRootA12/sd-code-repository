package sjs.api.dictionary;



/**
 * <p>
 * Title: DictEntry Class - A class component of the Dictionary system
 * </p>
 *
 * <p>
 * Description: An entity object class that implements a dictionary entry
 * </p>
 *
 * <p>
 * Copyright: Copyright © 2018-05-05
 * </p>
 *
 * @author Lynn Robert Carter
 * @author JSGREWAL, Sumit, Shivam
 * @version 2.00 - Baseline for transition from Swing to JavaFX 2018-05-05
 * @version 2.01 - Installed in PKMT Tool
 * @version 3.00 - Modified to support definitions of both String and CalculatorValue types
 * 				   for DictionaryAPI which will work on either Programmable Calculator or
 * 				   the Knowledge Management Tool.
 */

public class DictEntry {

	/**********************************************************************************************

	Class Attributes

	 **********************************************************************************************/
	private String word;			// A dictionary entry's word
	@SuppressWarnings("rawtypes") // This warning is suppressed as we will use generic DicType object for storing definitions.
	private DicType definition;		// A dictionary entry's definition of generic DicType
	// This value defines if the entry is a variable or constant.
	// true means the entry is variable and false means the entry is constant.
	// In case the API is plugged in with the KM Tool, value of this attribute doesn't matter and won't be used.
	private boolean isVariable=false; 

	/**********************************************************************************************

	Constructors

	 **********************************************************************************************/


	/**********
	 * This is defining constructor for String Type Definition.  This is the one we expect people to use in case the API is plugged in with
	 * Knowledge Management Tool.
	 * @param w Word
	 * @param d Definition of the Word
	 */
	public DictEntry(String w, String d) {
		word = w;
		definition = new DicType<String>(d);
	}
	/***
	 * This is defining constructor for CalculatorValue Type Definition. This is the one we expect people to use in case the API is plugged in 
	 * with Programmable Calculator.
	 * @param s Symbol
	 * @param c The CalculatorValue object which will have the measured value, error term and unit of the variable or constant.
	 * @param b Boolean value, true indicates that the object is a variable and false indicates that the object is constant.
	 */
	public DictEntry(String s, CalculatorValue c, boolean b) {
		word = s;
		definition = new DicType<CalculatorValue>(c);
		isVariable = b;
	}

	/**********************************************************************************************

	Standard support methods

	 **********************************************************************************************/

	/**********
	 * This is the debugging toString method.
	 */
	public String toString(){
		return word + "\n" + definition.toString();
	}

	/**********
	 * This is the formatted toString method.
	 */
	public String formattedToString(){
		return word + "\n" + definition.toString() + "\n--------------------\n";
	}

	/**********
	 * These are the getters and setters for the class
	 */

	/***
	 * Getter for Word / Symbol.
	 * @return The word /symbol.
	 */
	public String getWord(){
		return word;
	}
	/***
	 * Getter for Definition
	 * @return The Definition (In String Format)
	 */
	public String getDefinition(){
		return definition.toString();
	}
	/***
	 * Setter for Word / Symbol
	 * @param w New Word
	 */
	public void setWord(String w) {
		word=w;
	}
	/***
	 * Setter for Definition of String Format
	 * @param def New Definition
	 */
	public void setDefinition(String def) {
		this.definition=new DicType<String>(def);
	}
	/***
	 * Setter for Definition of Calculator Format
	 * @param def New CalculatorValue Format Definition
	 */
	public void setDefinition(CalculatorValue def) {
		this.definition = new DicType<CalculatorValue>(def);
	}
	/***
	 * This method tells the caller method if the current object is a variable or not (constant).
	 * @return true if the CalculatorValue is variable, else @return false if the CalculatorValue is constant.
	 */
	public boolean isItAVariable() {
		return this.isVariable;
	}


}
